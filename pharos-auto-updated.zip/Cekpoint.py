"""
Cekpoint.py
-----------

This simple utility script iterates over a list of private keys,
authenticates each wallet with the Pharos API and prints out the
current total point balance for each address.  It is intended to
provide a quick summary of your progress in the Pharos experience
program without performing any on‑chain actions.

The script reads private keys from ``privateKeys.txt``.  Keys should
be provided one per line without quotes; a ``0x`` prefix will be
added automatically if absent.  If the file is missing or empty, the
script will exit with an error message.

Example usage::

    python Cekpoint.py

Note: Do not store your private keys in version control.  Keep them
secure and consider using environment variables or a secure vault for
production use.
"""

import random
import time
from typing import Dict, List, Optional

import requests
from eth_account.messages import encode_defunct
from web3 import Web3

import config

# Instantiate a Web3 provider using the RPC URL defined in config.py
w3 = Web3(Web3.HTTPProvider(config.RPC_URL))

API_URL = "https://api.pharosnetwork.xyz"


def load_private_keys(path: str = "privateKeys.txt") -> List[str]:
    """
    Load private keys from a file.  Lines that are empty or contain only
    whitespace are ignored.
    """
    try:
        with open(path, "r", encoding="utf-8") as f:
            keys = [line.strip() for line in f if line.strip()]
        return keys
    except FileNotFoundError:
        return []


def sign_message(private_key: str, message: str = "pharos") -> str:
    """Sign a message and return the signature as hex."""
    acct = w3.eth.account.from_key(private_key)
    msg = encode_defunct(text=message)
    signed = acct.sign_message(msg)
    return signed.signature.hex()


def login_with_private_key(private_key: str) -> Optional[str]:
    """Authenticate with the Pharos API and return a JWT token."""
    try:
        address = w3.eth.account.from_key(private_key).address
        signature = sign_message(private_key)
        url = f"{API_URL}/user/login?address={address}&signature={signature}"
        headers = {
            "Origin": "https://testnet.pharosnetwork.xyz",
            "Referer": "https://testnet.pharosnetwork.xyz",
        }
        response = requests.post(url, headers=headers)
        data = response.json()
        return data.get("data", {}).get("jwt")
    except Exception as e:
        print(f"Gagal login untuk {private_key[:8]}…: {e}")
        return None


def get_profile_points(address: str, bearer_token: str) -> int:
    """
    Return the total points for a user.  If the request fails the function
    returns zero.
    """
    url = f"{API_URL}/user/profile?address={address}"
    headers = {
        "Authorization": f"Bearer {bearer_token}",
        "Origin": "https://testnet.pharosnetwork.xyz",
        "Referer": "https://testnet.pharosnetwork.xyz",
    }
    try:
        res = requests.get(url, headers=headers)
        if res.ok:
            data = res.json()
            return data.get("data", {}).get("user_info", {}).get("TotalPoints", 0)
        else:
            print(f"Gagal ambil profil untuk {address}, status code: {res.status_code}")
            return 0
    except Exception as e:
        print(f"Gagal ambil profil untuk {address}: {e}")
        return 0


def main() -> None:
    private_keys = load_private_keys()
    if not private_keys:
        print("File privateKeys.txt tidak ditemukan atau kosong.")
        return
    total_points = 0
    for pk in private_keys:
        # normalise the key
        if not pk.startswith("0x"):
            pk = "0x" + pk
        try:
            account = w3.eth.account.from_key(pk)
            address = account.address
        except Exception as e:
            print(f"Private key tidak valid: {e}")
            continue
        token = login_with_private_key(pk)
        if not token:
            print(f"Login gagal untuk {address}")
            continue
        points = get_profile_points(address, token)
        total_points += points
        print(f"{address} : {points}")
        # small random delay to avoid rate limiting
        time.sleep(random.uniform(1, 2))
    print("\nTotal poin semua akun:", total_points)


if __name__ == "__main__":
    main()