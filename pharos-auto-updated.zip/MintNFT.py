"""
MintNFT.py
-----------

This script automates the process of minting an NFT on the Gotchipus
contract which runs alongside the Pharos testnet.  Each wallet
specified in ``privateKeys.txt`` will attempt to mint exactly once.
Wallets that have already minted (as recorded in ``datanft.txt``)
will be skipped to avoid wasting gas.  A per‑wallet delay can be
configured via the ``DELAY_WALLET`` constant.

At the time of writing the Gotchipus minting contract is deployed
to a different RPC endpoint from the main Pharos testnet.  The
``RPC`` and ``CHAIN_ID`` constants below reflect the state of the
network as of August 2025.  If minting fails with an ``invalid
private key`` or ``gas price too low`` error you should verify
whether the chain ID or RPC URL have changed.  Refer to the official
Gotchipus or Pharos documentation for updated values.  The diamond
contract address used here (``CONTRACT_ADDRESS``) was taken from the
Gotchipus docs at that time.

The script writes successfully minted private keys and addresses to
``datanft.txt`` in the format ``<private_key> : <address>``.  Do not
share or commit this file to version control.

Example usage::

    python MintNFT.py

"""

import itertools
import time
from typing import Dict, List, Optional

from eth_account import Account
from eth_account.messages import encode_defunct
from eth_utils import to_checksum_address
from web3 import Web3
from web3.middleware import geth_poa_middleware


# RPC endpoint and chain ID for the Gotchipus minting contract.  If you
# experience connection errors or invalid nonce/gas errors, verify
# whether these values are still correct.
RPC: str = "https://gotchipus.com/api/testnet"
CHAIN_ID: int = 0xA8230  # hexadecimal literal for readability

# Explorer URL for constructing clickable transaction links.  This
# defaults to the Pharos scan explorer but can be updated if
# Gotchipus transactions are indexed elsewhere.
EXPLORER: str = "https://testnet.pharosscan.xyz/tx/"

# Gotchipus diamond contract address used for minting NFTs.
CONTRACT_ADDRESS: str = "0x0000000038f050528452d6da1e7aacfa7b3ec0a8"

# Function selector for the mint function.  This selector corresponds
# to the 4‑byte method ID of the mint function on the diamond
# contract.  Changing this will break the script.
MINT_FUNCTION_SELECTOR: str = "0x5b70ea9f"

# Number of retries for RPC calls and mint attempts
MAX_RETRY: int = 50

# Delay between wallets and between retries (seconds)
DELAY_WALLET: int = 5
DELAY_RETRY: int = 1


def print_banner() -> None:
    """Display an ASCII art banner."""
    banner = """
╭─────────────── Testnet Tools - Pharos Mint NFT ───────────────╮
│                                                               │
│ ████████╗███████╗███████╗████████╗███╗   ██╗███████╗████████╗ │
│ ╚══██╔══╝██╔════╝██╔════╝╚══██╔══╝████╗  ██║██╔════╝╚══██╔══╝ │
│    ██║   █████╗  ███████╗   ██║   ██╔██╗ ██║█████╗     ██║    │
│    ██║   ██╔══╝  ╚════██║   ██║   ██║╚██╗██║██╔══╝     ██║    │
│    ██║   ███████╗███████║   ██║   ██║ ╚████║███████╗   ██║    │
│    ╚═╝   ╚══════╝╚══════╝   ╚═╝   ╚═╝  ╚═══╝╚══════╝   ╚═╝    │
│                                                               │
╰─────────────────────── BY ADFMIDN TEAM ───────────────────────╯
"""
    print(banner)


def read_file(path: str) -> List[str]:
    """Return a list of non‑empty lines from a file."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        return []


def load_minted_data(filename: str = "datanft.txt") -> Dict[str, str]:
    """Load a mapping of private keys to addresses that have already minted."""
    minted: Dict[str, str] = {}
    try:
        with open(filename, "r", encoding="utf-8") as f:
            for line in f:
                if ":" in line:
                    pk, addr = line.strip().split(":", 1)
                    minted[pk.strip()] = addr.strip()
    except FileNotFoundError:
        pass
    return minted


def save_minted_data(private_key: str, address: str, filename: str = "datanft.txt") -> None:
    """Append a minted private key and address to the tracking file."""
    with open(filename, "a", encoding="utf-8") as f:
        f.write(f"{private_key} : {address}\n")


def wait_for_tx(w3: Web3, tx_hash: str, timeout: int = 60) -> bool:
    """
    Wait for a transaction to be mined or until timeout.  Returns ``True``
    if confirmed or ``False`` if it did not appear in the mempool in time.
    """
    print("   ⏳ Menunggu transaksi diproses...", end="", flush=True)
    for _ in range(timeout):
        try:
            tx = w3.eth.get_transaction(tx_hash)
            if tx and tx["blockHash"] != Web3.to_bytes(hexstr="0x0"):
                print("\n   ✅ Transaksi dikonfirmasi.")
                return True
        except Exception:
            pass
        print(".", end="", flush=True)
        time.sleep(1)
    print("\n   ❌ Transaksi tidak muncul setelah timeout.")
    return False


def mint_nft(w3: Web3, pk: str) -> Optional[str]:
    """Attempt to mint an NFT for the given private key.  Returns the tx hash."""
    acct = Account.from_key(pk)
    checksum_address = to_checksum_address(acct.address)
    print(f"   📬 Address \t\t: {checksum_address}")
    # Ensure the wallet has a non‑zero balance before attempting to mint
    for attempt in range(1, MAX_RETRY + 1):
        try:
            nonce = w3.eth.get_transaction_count(checksum_address)
            balance_wei = w3.eth.get_balance(checksum_address)
            balance_phrs = w3.from_wei(balance_wei, "ether")
            print(f"   💰 Balance PHRS \t: {balance_phrs:.4f}")
            if balance_phrs == 0:
                print("   ⚠️  Balance 0 PHRS, kemungkinan belum faucet.")
                return None
            break
        except Exception:
            if attempt < MAX_RETRY:
                time.sleep(DELAY_RETRY)
            else:
                print("   ❌ Gagal koneksi setelah beberapa percobaan.")
                return None
    # Build and send the mint transaction
    for attempt in range(1, MAX_RETRY + 1):
        try:
            gas_price = w3.eth.gas_price
            txn = {
                "to": to_checksum_address(CONTRACT_ADDRESS),
                "from": checksum_address,
                "value": 0,
                "gas": 300_000,
                "gasPrice": gas_price,
                "nonce": nonce,
                "chainId": CHAIN_ID,
                "data": MINT_FUNCTION_SELECTOR,
            }
            signed_txn = w3.eth.account.sign_transaction(txn, private_key=pk)
            tx_hash = w3.eth.send_raw_transaction(signed_txn.rawTransaction)
            tx_hash_hex = tx_hash.hex()
            print(f"   🔁 Attempt {attempt}: Mint NFT terkirim.")
            if wait_for_tx(w3, tx_hash_hex):
                print(f"   🔗 Explorer: {EXPLORER}{tx_hash_hex}")
                return tx_hash_hex
            else:
                print("   ⚠️ Transaksi tidak terkonfirmasi, mencoba lagi…")
        except Exception:
            # fall through to retry after delay
            time.sleep(DELAY_RETRY)
    print("   ❌ Gagal mint setelah beberapa percobaan.")
    return None


def assign_proxies(private_keys: List[str], proxies: List[str]) -> List[Dict[str, Optional[str]]]:
    """
    Interleave proxies with private keys.  If fewer proxies than keys are
    provided the proxies will be cycled.
    """
    wallets = []
    if proxies:
        proxy_cycle = itertools.cycle(proxies)
        for pk in private_keys:
            wallets.append({"private_key": pk, "proxy": next(proxy_cycle)})
    else:
        for pk in private_keys:
            wallets.append({"private_key": pk, "proxy": None})
    return wallets


def print_separator() -> None:
    print("=" * 60)


def main() -> None:
    print_banner()
    private_keys = read_file("privateKeys.txt")
    if not private_keys:
        print("File privateKeys.txt tidak ditemukan atau kosong.")
        return
    proxies = read_file("proxy.txt")
    minted_data = load_minted_data()
    wallets = assign_proxies(private_keys, proxies)
    for idx, wallet in enumerate(wallets, 1):
        pk = wallet["private_key"]
        proxy = wallet["proxy"]
        print_separator()
        print(f"[{idx}] Memproses wallet")
        # Skip if this private key already minted
        if pk in minted_data:
            print("   ✅ Sudah pernah mint. Lewati.")
            continue
        # Normalise the key
        if not pk.startswith("0x"):
            pk = "0x" + pk
        # Create a Web3 instance, injecting the proxy if provided
        if proxy:
            w3_instance = Web3(Web3.HTTPProvider(RPC, request_kwargs={"proxies": {"http": proxy, "https": proxy}}))
            print(f"   🔗 Menggunakan proxy: {proxy}")
        else:
            w3_instance = Web3(Web3.HTTPProvider(RPC))
            print("   🔗 Tidak menggunakan proxy")
        # Inject the PoA middleware; Gotchipus uses a Geth POA setup
        w3_instance.middleware_onion.inject(geth_poa_middleware, layer=0)
        tx_hash = mint_nft(w3_instance, pk)
        if tx_hash:
            acct = Account.from_key(pk)
            save_minted_data(pk, acct.address)
        print(f"   ⏳ Delay {DELAY_WALLET}s sebelum ke wallet berikutnya…")
        time.sleep(DELAY_WALLET)
    print_separator()


if __name__ == "__main__":
    main()