"""
bot.py
------

This module contains a multi‑wallet automation bot for interacting with the
Pharos testnet.  It automates a handful of activities that earn points on
the Pharos "Experience" system, such as sending native PHRS transfers,
performing token swaps and adding liquidity via Uniswap V3.  The script is
designed to work with the configuration defined in :mod:`config.py` which
encapsulates network parameters (RPC URL, chain ID, contract addresses and
ABIs).  To update the bot for a future testnet deployment, modify
``pharos-auto-updated/config.py`` instead of editing this file directly.

The workflow for each wallet is as follows:

1.  Log in to the Pharos API by signing a message with the wallet's
    private key.  The API returns a JWT token used for subsequent
    requests.
2.  Retrieve profile information to display current points and perform a
    daily check‑in if available.
3.  Perform a number of native transfers to randomly generated addresses
    (defaults to 0.001–0.002 PHRS).  Each transaction is verified via the
    API to ensure it is counted towards the user's tasks.
4.  Execute a series of token swaps from WPHRS to USDC using the
    Uniswap V3 router.  The amount is randomised within a small range to
    mimic organic activity.
5.  Add liquidity to the WPHRS/USDC pool via the non‑fungible position
    manager.  Both amounts are currently hard‑coded to 0.01 PHRS and
    0.01 USDC but can be tuned.

The script reads private keys from ``privateKeys.txt`` (one per line)
and optional proxy servers from ``proxy.txt``.  Proxy entries should be
valid HTTP(S) URLs; proxies will be cycled through when processing
multiple wallets.  **Never commit your private keys or proxies to
version control.**

Usage:

::

   python bot.py

You will be prompted for the number of native transfers, swaps and
liquidity operations to perform per wallet.  The script then iterates
over each private key, logs in, and performs the requested actions.

Note that sending transactions and interacting with the Uniswap router
requires the wallets to have sufficient PHRS, WPHRS and USDC balances on
the Pharos testnet.  You should use a faucet or bridge to fund your
wallets before running this script.
"""

import datetime
import json
import random
import time
from typing import List, Optional, Tuple

import requests
from eth_account.messages import encode_defunct
from colorama import Fore, init
from rich.console import Console
from rich.panel import Panel
from web3 import Web3

import config

# initialise colour output
init(autoreset=True)
console = Console()

# Instantiate a base Web3 provider without proxies for signing messages.
# For per‑wallet operations a new provider with proxy configuration will
# be created.
w3 = Web3(Web3.HTTPProvider(config.RPC_URL))

# Extract constants from the configuration for easy reference.
CHAIN_ID: int = config.CHAIN_ID
EXPLORER: str = config.EXPLORER
DELAY_BETWEEN_TX: int = getattr(config, "DELAY_BETWEEN_TX", 10)

# Token and contract addresses
WPHRS_ADDRESS = config.WPHRS_ADDRESS
USDC_ADDRESS = config.USDC_ADDRESS
USDT_ADDRESS = config.USDT_ADDRESS
POSITION_MANAGER_ADDRESS = config.POSITIONMANAGER_ADDRESS
SWAP_ROUTER_ADDRESS = config.SWAP_ROUTER_ADDRESS
QUOTER_ADDRESS = config.QUOTER
USDC_POOL_ADDRESS = config.USDC_POOL_ADDRESS
USDT_POOL_ADDRESS = config.USDT_POOL_ADDRESS

# ABIs
ERC20_ABI = config.ERC20_ABI
POSITION_MANAGER_ABI = config.POSITION_MANAGER_ABI
SWAP_ROUTER_ABI = config.SWAP_ROUTER_ABI

# Base URL for the Pharos API.  Change this if the API endpoint moves.
API_URL = "https://api.pharosnetwork.xyz"


def tampil_banner() -> None:
    """Print an ASCII banner to the console."""
    banner = """[bold cyan]
████████╗███████╗███████╗████████╗███╗   ██╗███████╗████████╗
╚══██╔══╝██╔════╝██╔════╝╚══██╔══╝████╗  ██║██╔════╝╚══██╔══╝
   ██║   █████╗  ███████╗   ██║   ██╔██╗ ██║█████╗     ██║   
   ██║   ██╔══╝  ╚════██║   ██║   ██║╚██╗██║██╔══╝     ██║   
   ██║   ███████╗███████║   ██║   ██║ ╚████║███████╗   ██║   
   ╚═╝   ╚══════╝╚══════╝   ╚═╝   ╚═╝  ╚═══╝╚══════╝   ╚═╝   
[/bold cyan]"""
    console.print(Panel.fit(banner, title="[bold yellow]Testnet Tools - Pharos Testnet[/bold yellow]", subtitle="BY ADFMIDN TEAM"))


def load_lines(path: str) -> List[str]:
    """
    Return a list of non‑empty, stripped lines from a file.

    :param path: File path to read.  If the file does not exist an
        empty list is returned.
    """
    try:
        with open(path, "r", encoding="utf-8") as f:
            return [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        return []


def generate_random_address() -> str:
    """Generate a random EVM address using Web3 Account.create()."""
    return w3.eth.account.create().address


def acak_angka(min_val: float, max_val: float) -> float:
    """
    Generate a random floating point number with six decimal places.

    :param min_val: Minimum value.
    :param max_val: Maximum value.
    """
    return round(random.uniform(min_val, max_val), 6)


def sign_message(private_key: str, message: str = "pharos") -> str:
    """
    Sign an arbitrary message using an EVM private key.

    :returns: Hex‑encoded signature.
    """
    acct = w3.eth.account.from_key(private_key)
    msg = encode_defunct(text=message)
    signed = acct.sign_message(msg)
    return signed.signature.hex()


def login_with_private_key(private_key: str) -> Optional[str]:
    """
    Authenticate with the Pharos API using a wallet's private key.

    :returns: JWT bearer token on success, or ``None`` on failure.
    """
    try:
        address = w3.eth.account.from_key(private_key).address
        signature = sign_message(private_key)
        url = f"{API_URL}/user/login?address={address}&signature={signature}"
        headers = {
            "Origin": "https://testnet.pharosnetwork.xyz",
            "Referer": "https://testnet.pharosnetwork.xyz",
        }
        response = requests.post(url, headers=headers)
        data = response.json()
        return data.get("data", {}).get("jwt")
    except Exception as e:
        print(f"❌ Gagal login: {e}")
        return None


def get_profile_info(address: str, bearer_token: str) -> dict:
    """
    Fetch user profile information from the Pharos API.

    :param address: Wallet address.
    :param bearer_token: JWT token returned by :func:`login_with_private_key`.
    :returns: Parsed JSON dictionary on success, empty dict on failure.
    """
    url = f"{API_URL}/user/profile?address={address}"
    headers = {
        "Authorization": f"Bearer {bearer_token}",
        "Origin": "https://testnet.pharosnetwork.xyz",
        "Referer": "https://testnet.pharosnetwork.xyz",
    }
    try:
        res = requests.get(url, headers=headers)
        if res.ok:
            data = res.json()
            points = data.get("data", {}).get("user_info", {}).get("TotalPoints", 0)
            print(f"📋 Poin: {points}")
            return data
        else:
            print("❌ Gagal ambil profil")
            return {}
    except Exception as e:
        print(f"❌ Gagal ambil profil: {e}")
        return {}


def get_today_index() -> int:
    """Return the zero‑based index of the current day in the week (0=Monday)."""
    return datetime.datetime.today().weekday()


def is_checkin_available(status_str: str) -> Tuple[bool, str]:
    """
    Determine whether the daily check‑in is available based on the status string.

    The status string is a seven‑character string where each character
    corresponds to a day of the week:

    * ``0`` — already checked in
    * ``1`` — skipped
    * ``2`` — available to check in

    :returns: Tuple of a boolean indicating availability and a user friendly
        message.
    """
    index = get_today_index()
    if len(status_str) != 7:
        return False, "⚠️ Status tidak valid."
    char_today = status_str[index]
    if char_today == "2":
        return True, "🕓 Belum check-in, akan mencoba check-in."
    elif char_today == "0":
        return False, "ℹ️ Sudah check-in hari ini."
    elif char_today == "1":
        return False, "⏭️ Hari ini dilewati."
    else:
        return False, "❌ Status tidak dikenal."


def checkin(address: str, token: str) -> None:
    """Perform the daily check‑in for the given address."""
    headers = {
        "Authorization": f"Bearer {token}",
        "Referer": "https://testnet.pharosnetwork.xyz/",
        "Origin": "https://testnet.pharosnetwork.xyz",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "Accept": "application/json, text/plain, */*",
    }
    url_status = f"{API_URL}/sign/status?address={address}"
    try:
        res = requests.get(url_status, headers=headers)
        if res.ok:
            status_str = res.json().get("data", {}).get("status", "2222222")
            available, info = is_checkin_available(status_str)
            print(info)
            if available:
                url_checkin = f"{API_URL}/sign/in?address={address}"
                res_checkin = requests.post(url_checkin, headers=headers)
                if res_checkin.ok:
                    print("✅ Check-in berhasil!")
                else:
                    print(f"❌ Gagal check-in: {res_checkin.text}")
            else:
                print("ℹ️ Tidak melakukan check-in.")
        else:
            print(f"⚠️ Gagal mendapatkan status check-in: {res.text}")
    except Exception as e:
        print(f"❌ Error saat check-in: {e}")


def send_transaction(private_key: str, to_address: str, value: float = 0.001) -> Tuple[str, str]:
    """
    Send a native PHRS transfer from ``private_key`` to ``to_address``.

    :param value: Amount of PHRS to send (in ether units).
    :returns: Tuple of the transaction hash and sender address.
    """
    account = w3.eth.account.from_key(private_key)
    sender = account.address
    value_wei = w3.to_wei(value, "ether")
    nonce = w3.eth.get_transaction_count(sender)
    tx = {
        "chainId": CHAIN_ID,
        "to": to_address,
        "value": value_wei,
        "gas": 21_000,
        "gasPrice": w3.to_wei(1.2, "gwei"),
        "nonce": nonce,
    }
    signed_tx = w3.eth.account.sign_transaction(tx, private_key)
    tx_hash = w3.eth.send_raw_transaction(signed_tx.rawTransaction)
    w3.eth.wait_for_transaction_receipt(tx_hash)
    return tx_hash.hex(), sender


def verify_transaction(address: str, tx_hash: str, bearer_token: str) -> dict:
    """
    Inform the Pharos API about a completed native transfer.

    :returns: Parsed JSON response from the API.
    """
    url = f"{API_URL}/task/verify?address={address}&task_id=103&tx_hash={tx_hash}"
    headers = {
        "Authorization": f"Bearer {bearer_token}",
        "Origin": "https://testnet.pharosnetwork.xyz",
        "Referer": "https://testnet.pharosnetwork.xyz",
    }
    try:
        return requests.post(url, headers=headers).json()
    except Exception as e:
        return {"error": str(e)}


def swap_token(private_key: str) -> None:
    """Swap a small amount of WPHRS to USDC using the Uniswap router."""
    amount_eth = acak_angka(0.001, 0.002)
    amount_in_wei = w3.to_wei(amount_eth, "ether")
    account = w3.eth.account.from_key(private_key)
    address = account.address
    nonce = w3.eth.get_transaction_count(address)
    token = w3.eth.contract(address=WPHRS_ADDRESS, abi=ERC20_ABI)
    router = w3.eth.contract(address=SWAP_ROUTER_ADDRESS, abi=SWAP_ROUTER_ABI)

    # Approve the router to spend our WPHRS
    approve_tx = token.functions.approve(SWAP_ROUTER_ADDRESS, amount_in_wei).build_transaction({
        "from": address,
        "nonce": nonce,
        "gas": 60_000,
        "gasPrice": w3.eth.gas_price,
        "chainId": CHAIN_ID,
    })
    signed_approve = w3.eth.account.sign_transaction(approve_tx, private_key)
    w3.eth.send_raw_transaction(signed_approve.rawTransaction)
    time.sleep(5)

    params = {
        "tokenIn": WPHRS_ADDRESS,
        "tokenOut": USDC_ADDRESS,
        "fee": 500,
        "recipient": address,
        "amountIn": amount_in_wei,
        "amountOutMinimum": 0,
        "sqrtPriceLimitX96": 0,
    }
    swap_tx = router.functions.exactInputSingle(params).build_transaction({
        "from": address,
        "nonce": nonce + 1,
        "gas": 300_000,
        "gasPrice": w3.eth.gas_price,
        "chainId": CHAIN_ID,
    })
    signed_tx = w3.eth.account.sign_transaction(swap_tx, private_key)
    tx_hash = w3.eth.send_raw_transaction(signed_tx.rawTransaction)
    print(f"✅ Swap sukses: {EXPLORER}{tx_hash.hex()}")


def add_liquidity(
    w3: Web3,
    private_key: str,
    token0_address: str,
    token1_address: str,
    amount0: int,
    amount1: int,
    position_manager: str,
    position_manager_abi: list,
    fee: int,
) -> str:
    """
    Add liquidity to the specified token pair using the Uniswap non‑fungible
    position manager.  Returns the transaction hash.
    """
    wallet = w3.eth.account.from_key(private_key)
    address = wallet.address
    token0 = w3.eth.contract(address=token0_address, abi=ERC20_ABI)
    token1 = w3.eth.contract(address=token1_address, abi=ERC20_ABI)
    position_manager_contract = w3.eth.contract(address=position_manager, abi=position_manager_abi)
    nonce = w3.eth.get_transaction_count(address)

    # Approve both tokens
    approve_tx1 = token0.functions.approve(position_manager, amount0).build_transaction({
        "from": address,
        "nonce": nonce,
        "gas": 200_000,
        "gasPrice": w3.eth.gas_price,
    })
    signed_tx1 = w3.eth.account.sign_transaction(approve_tx1, private_key)
    w3.eth.send_raw_transaction(signed_tx1.rawTransaction)
    time.sleep(3)

    approve_tx2 = token1.functions.approve(position_manager, amount1).build_transaction({
        "from": address,
        "nonce": nonce + 1,
        "gas": 200_000,
        "gasPrice": w3.eth.gas_price,
    })
    signed_tx2 = w3.eth.account.sign_transaction(approve_tx2, private_key)
    w3.eth.send_raw_transaction(signed_tx2.rawTransaction)
    time.sleep(3)

    # Prepare mint parameters.  The tick range is chosen arbitrarily; adjust
    # according to your strategy.  Deadline is 10 minutes from now.
    deadline = int(time.time()) + 600
    tick_lower = -60_000
    tick_upper = 60_000
    mint_params = {
        "token0": token0_address,
        "token1": token1_address,
        "fee": fee,
        "tickLower": tick_lower,
        "tickUpper": tick_upper,
        "amount0Desired": amount0,
        "amount1Desired": amount1,
        "amount0Min": 0,
        "amount1Min": 0,
        "recipient": address,
        "deadline": deadline,
    }
    mint_tx = position_manager_contract.functions.mint(mint_params).build_transaction({
        "from": address,
        "nonce": nonce + 2,
        "value": 0,
        "gas": 800_000,
        "gasPrice": w3.eth.gas_price,
    })
    signed_tx3 = w3.eth.account.sign_transaction(mint_tx, private_key)
    tx_hash3 = w3.eth.send_raw_transaction(signed_tx3.rawTransaction)
    print("💧 LP Mint dikirim...")
    w3.eth.wait_for_transaction_receipt(tx_hash3)
    return tx_hash3.hex()


def main() -> None:
    """Main entry point for the Pharos automation bot."""
    tampil_banner()
    print(Fore.GREEN + "Bot Pharos dimulai...\n")
    try:
        jumlah_tx = int(input("Jumlah transaksi per wallet: "))
        jumlah_swap = int(input("Jumlah swap per wallet: "))
        jumlah_lp = int(input("Jumlah add LP per wallet: "))
    except ValueError:
        print("Masukkan angka yang valid.")
        return

    private_keys = load_lines("privateKeys.txt")
    if not private_keys:
        print("File privateKeys.txt tidak ditemukan atau kosong.")
        return
    proxies = load_lines("proxy.txt")

    for i, pk in enumerate(private_keys):
        print("=" * 50)
        print(f"▶️ Wallet #{i + 1}")

        # normalise private key to 0x-prefixed 64‑hex string
        if not pk.startswith("0x"):
            pk = "0x" + pk

        proxy = proxies[i % len(proxies)] if proxies else None
        proxy_kwargs = {"proxies": {"http": proxy, "https": proxy}} if proxy else {}
        try:
            # Recreate a Web3 instance using the proxy (if any).  We
            # reuse the global CHAIN_ID here.
            local_w3 = Web3(Web3.HTTPProvider(config.RPC_URL, request_kwargs=proxy_kwargs))
            account = local_w3.eth.account.from_key(pk)
            address = account.address
            print(f"Wallet Address: {address}")
        except Exception as e:
            print(f"❌ Private key tidak valid atau koneksi RPC gagal: {e}")
            continue

        token = login_with_private_key(pk)
        if not token:
            print("❌ Login gagal.")
            continue
        print("✅ Login berhasil!")

        try:
            profile = get_profile_info(address, token)
            checkin(address, token)
        except Exception as e:
            print(f"❗ Gagal ambil profil atau checkin: {e}")

        # Native transfers
        for txi in range(1, jumlah_tx + 1):
            print(f"\n🔄 Transaksi native #{txi}")
            tujuan = generate_random_address()
            print(f"Alamat tujuan: {tujuan}")
            try:
                tx_hash, sender = send_transaction(pk, tujuan)
                print(f"✅ TX berhasil: {tx_hash}")
                verif = verify_transaction(sender, tx_hash, token)
                if verif.get("code") == 0 and verif.get("data", {}).get("verified"):
                    print("🔒 Verifikasi sukses!")
                else:
                    print("❌ Verifikasi gagal.")
                profil = get_profile_info(sender, token)
                poin = profil.get("data", {}).get("user_info", {}).get("TaskPoints", 0)
                print(f"🎯 Total Poin: {poin}")
                if txi < jumlah_tx:
                    print(f"⏳ Menunggu {DELAY_BETWEEN_TX} detik...")
                    time.sleep(DELAY_BETWEEN_TX)
            except Exception as e:
                print(f"❗ Kesalahan: {str(e)}")
                time.sleep(5)

        # Token swaps
        for sxi in range(1, jumlah_swap + 1):
            print(f"\n🔁 Swap token #{sxi}")
            try:
                swap_token(pk)
                time.sleep(5)
            except Exception as e:
                print(f"❗ Gagal swap: {e}")

        # Add liquidity
        for lpi in range(1, jumlah_lp + 1):
            print(f"\n💧 Add LP #{lpi}")
            try:
                amount0 = w3.to_wei(0.01, "ether")
                amount1 = w3.to_wei(0.01, "ether")
                tx_hash = add_liquidity(
                    w3,
                    pk,
                    WPHRS_ADDRESS,
                    USDC_ADDRESS,
                    amount0,
                    amount1,
                    POSITION_MANAGER_ADDRESS,
                    POSITION_MANAGER_ABI,
                    3_000,
                )
                print(f"✅ Add LP selesai: {EXPLORER}{tx_hash}")
                time.sleep(DELAY_BETWEEN_TX)
            except Exception as e:
                print(f"❌ Gagal LP: {str(e)}")
                time.sleep(5)


if __name__ == "__main__":
    main()