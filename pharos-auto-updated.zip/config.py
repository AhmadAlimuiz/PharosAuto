"""
Configuration and contract settings for Pharos Testnet automation.

This module centralises all of the network parameters and contract
addresses used by the automation scripts.  As the Pharos Testnet
evolves the RPC endpoint, chain ID and token addresses may change.
Updating this file allows the rest of the scripts to pick up the
latest values without modification.

The default values here are sourced from the Pharos documentation
available in August 2025.  If you notice your transactions failing
because a token or router address is no longer valid, consult the
official docs at https://docs.pharosnetwork.xyz/ and update the
appropriate constant below.
"""

from web3 import Web3

# ---------------------------------------------------------------------------
# Network configuration
#
# The RPC_URL and CHAIN_ID constants describe the Pharos testnet.  These
# values should match the settings you add in MetaMask or another EVM
# compatible wallet.  See the Pharos docs for up‑to‑date values:
# https://docs.pharosnetwork.xyz/network-overview/pharos-networks

# Public RPC endpoint for the Pharos testnet.  Requests are rate‑limited,
# so consider running your own node if you encounter HTTP 429 errors.
RPC_URL: str = "https://testnet.dplabs-internal.com"

# Chain ID for the Pharos testnet.  Used when signing raw transactions.
CHAIN_ID: int = 688688

# Explorer base URL.  This is used by the bots to construct links to
# transaction receipts in log output.
EXPLORER: str = "https://testnet.pharosscan.xyz/tx/"

# Optional delay (in seconds) between back‑to‑back transactions.  Some
# users prefer a small pause to avoid triggering rate limits.  Bots
# import this attribute using getattr to provide a default when it is
# absent.
DELAY_BETWEEN_TX: int = 10

# ---------------------------------------------------------------------------
# Token and contract addresses
#
# These addresses correspond to wrapped PHRS (WPHRS) and stablecoins on
# the Pharos testnet.  They were obtained from the Pharos Testnet
# Information page (see lines 193–241)【351396378061401†L193-L241】.  Update them
# when the testnet is redeployed or upgraded.

WPHRS_ADDRESS = Web3.to_checksum_address("0x3019B247381c850ab53Dc0EE53bCe7A07Ea9155f")
USDC_ADDRESS  = Web3.to_checksum_address("0x72df0bcd7276f2dFbAc900D1CE63c272C4BCcCED")
USDT_ADDRESS  = Web3.to_checksum_address("0xD4071393f8716661958F766DF660033b3d35fD29")

# The addresses below are part of the Uniswap V3 deployment on the
# Pharos testnet.  If your swaps or liquidity operations fail, check
# whether these values have changed on the latest network deployment.
# At the time of writing there is no public reference for these
# contracts, so they are retained from the original script.  Feel free
# to update them as needed.
POSITIONMANAGER_ADDRESS = Web3.to_checksum_address("0xF8a1D4FF0f9b9Af7CE58E1fc1833688F3BFd6115")
FACTORY                  = Web3.to_checksum_address("0x7CE5b44F2d05babd29caE68557F52ab051265F01")
QUOTER                   = Web3.to_checksum_address("0x00f2f47d1ed593Cf0AF0074173E9DF95afb0206C")
SWAP_ROUTER_ADDRESS      = Web3.to_checksum_address("0x1a4de519154ae51200b0ad7c90f7fac75547888a")
USDC_POOL_ADDRESS        = Web3.to_checksum_address("0x0373a059321219745aee4fad8a942cf088be3d0e")
USDT_POOL_ADDRESS        = Web3.to_checksum_address("0x70118b6eec45329e0534d849bc3e588bb6752527")

# ---------------------------------------------------------------------------
# ABIs
#
# The following ABI definitions allow the scripts to interact with
# ERC‑20 tokens and the Uniswap V3 contracts.  They are unchanged from
# the original repository.  For readability the ABIs have been kept
# compact; additional function definitions can be added as needed.

ERC20_ABI = [
    {
        "constant": True,
        "inputs": [{"name": "owner", "type": "address"}],
        "name": "balanceOf",
        "outputs": [{"name": "balance", "type": "uint256"}],
        "type": "function",
    },
    {
        "constant": False,
        "inputs": [
            {"name": "spender", "type": "address"},
            {"name": "amount", "type": "uint256"},
        ],
        "name": "approve",
        "outputs": [{"name": "", "type": "bool"}],
        "type": "function",
    },
    {
        "constant": True,
        "inputs": [
            {"name": "owner", "type": "address"},
            {"name": "spender", "type": "address"},
        ],
        "name": "allowance",
        "outputs": [{"name": "", "type": "uint256"}],
        "type": "function",
    },
    {
        "constant": False,
        "inputs": [
            {"name": "to", "type": "address"},
            {"name": "amount", "type": "uint256"},
        ],
        "name": "transfer",
        "outputs": [{"name": "", "type": "bool"}],
        "type": "function",
    },
]

# Partial Uniswap V3 SwapRouter ABI.  Only the functions used by the
# bot are included.  Additional methods can be appended if you wish
# to support more complex swap operations.
SWAP_ROUTER_ABI = [
    {
        "inputs": [
            {
                "components": [
                    {"internalType": "address", "name": "tokenIn", "type": "address"},
                    {"internalType": "address", "name": "tokenOut", "type": "address"},
                    {"internalType": "uint24", "name": "fee", "type": "uint24"},
                    {"internalType": "address", "name": "recipient", "type": "address"},
                    {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
                    {"internalType": "uint256", "name": "amountOutMinimum", "type": "uint256"},
                    {"internalType": "uint160", "name": "sqrtPriceLimitX96", "type": "uint160"},
                ],
                "internalType": "struct IV3SwapRouter.ExactInputSingleParams",
                "name": "params",
                "type": "tuple",
            },
        ],
        "name": "exactInputSingle",
        "outputs": [{"internalType": "uint256", "name": "amountOut", "type": "uint256"}],
        "stateMutability": "payable",
        "type": "function",
    },
    {
        "inputs": [
            {
                "components": [
                    {"internalType": "bytes", "name": "path", "type": "bytes"},
                    {"internalType": "address", "name": "recipient", "type": "address"},
                    {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
                    {"internalType": "uint256", "name": "amountOutMinimum", "type": "uint256"},
                ],
                "internalType": "struct IV3SwapRouter.ExactInputParams",
                "name": "params",
                "type": "tuple",
            },
        ],
        "name": "exactInput",
        "outputs": [{"internalType": "uint256", "name": "amountOut", "type": "uint256"}],
        "stateMutability": "payable",
        "type": "function",
    },
    {
        "inputs": [{"internalType": "bytes[]", "name": "data", "type": "bytes[]"}],
        "name": "multicall",
        "outputs": [{"internalType": "bytes[]", "name": "results", "type": "bytes[]"}],
        "stateMutability": "payable",
        "type": "function",
    },
]

# ABI for the non‑fungible position manager used for adding liquidity.
# See https://docs.uniswap.org/contracts/v3/reference/core/interfaces for
# details.  Only the functions used by the bot are defined here.
POSITION_MANAGER_ABI = [
    {
        "inputs": [
            {
                "components": [
                    {"internalType": "address", "name": "token0", "type": "address"},
                    {"internalType": "address", "name": "token1", "type": "address"},
                    {"internalType": "uint24", "name": "fee", "type": "uint24"},
                    {"internalType": "int24", "name": "tickLower", "type": "int24"},
                    {"internalType": "int24", "name": "tickUpper", "type": "int24"},
                    {"internalType": "uint256", "name": "amount0Desired", "type": "uint256"},
                    {"internalType": "uint256", "name": "amount1Desired", "type": "uint256"},
                    {"internalType": "uint256", "name": "amount0Min", "type": "uint256"},
                    {"internalType": "uint256", "name": "amount1Min", "type": "uint256"},
                    {"internalType": "address", "name": "recipient", "type": "address"},
                    {"internalType": "uint256", "name": "deadline", "type": "uint256"},
                ],
                "internalType": "struct INonfungiblePositionManager.MintParams",
                "name": "params",
                "type": "tuple",
            }
        ],
        "name": "mint",
        "outputs": [
            {"internalType": "uint256", "name": "tokenId", "type": "uint256"},
            {"internalType": "uint128", "name": "liquidity", "type": "uint128"},
            {"internalType": "uint256", "name": "amount0", "type": "uint256"},
            {"internalType": "uint256", "name": "amount1", "type": "uint256"},
        ],
        "stateMutability": "payable",
        "type": "function",
    },
    {
        "inputs": [
            {
                "components": [
                    {"internalType": "uint256", "name": "tokenId", "type": "uint256"},
                    {"internalType": "uint256", "name": "amount0Desired", "type": "uint256"},
                    {"internalType": "uint256", "name": "amount1Desired", "type": "uint256"},
                    {"internalType": "uint256", "name": "amount0Min", "type": "uint256"},
                    {"internalType": "uint256", "name": "amount1Min", "type": "uint256"},
                    {"internalType": "uint256", "name": "deadline", "type": "uint256"},
                ],
                "internalType": "struct INonfungiblePositionManager.IncreaseLiquidityParams",
                "name": "params",
                "type": "tuple",
            }
        ],
        "name": "increaseLiquidity",
        "outputs": [
            {"internalType": "uint128", "name": "liquidity", "type": "uint128"},
            {"internalType": "uint256", "name": "amount0", "type": "uint256"},
            {"internalType": "uint256", "name": "amount1", "type": "uint256"},
        ],
        "stateMutability": "payable",
        "type": "function",
    },
]